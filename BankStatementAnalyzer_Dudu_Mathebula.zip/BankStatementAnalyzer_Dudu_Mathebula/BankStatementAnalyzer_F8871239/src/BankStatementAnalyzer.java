import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Map;


public class BankStatementAnalyzer {
    private static final String RESOURCES = "src/";
    //private static final BankStatementCSVParser bankStatementParser = new BankStatementCSVParser();


    public void analyze(final String fileName, final BankStatementParser bankStatementParser)
            throws IOException {

        final Path path = Paths.get(RESOURCES + fileName);
        final List<String> lines = Files.readAllLines(path);

        final List<BankTransaction> bankTransactions = bankStatementParser.parseLinesFrom(lines);
        final BankStatementProcessor bankStatementProcessor = new BankStatementProcessor(bankTransactions);

        collectSummary(bankStatementProcessor);
    }


    private static void collectSummary(final BankStatementProcessor bankStatementProcessor) {
        System.out.println("The total for all transactions is "
                + bankStatementProcessor.calculateTotalAmount());

        System.out.println("The total for transactions in January is: "
                + bankStatementProcessor.calculateTotalInMonth(Month.JANUARY));

        System.out.println("The total for transactions in February is: "
                + bankStatementProcessor.calculateTotalInMonth(Month.FEBRUARY));

        System.out.println("The total salary received is: "
                + bankStatementProcessor.calculateTotalForCategory("Salary"));

        LocalDate startDate = LocalDate.of(2017, Month.JANUARY,30);
        LocalDate endDate   = LocalDate.of(2017, Month.FEBRUARY , 05);

        BankTransaction maxTransaction = bankStatementProcessor.findMaximumTransactionInDateRange(startDate, endDate);
        BankTransaction minTransaction = bankStatementProcessor.findMinimumTransactionInDateRange(startDate, endDate);

        System.out.println("The maximum expenditure between " + startDate + " and " + endDate + ":");
        printTransaction(maxTransaction);

        System.out.println("The minimum expenditure between " + startDate + " and " + endDate + ":");
        printTransaction(minTransaction);

        System.out.println("Histogram of Expenses:");
        printHistogram(bankStatementProcessor.getExpenseHistogram());
    }
    private static void printTransaction(BankTransaction transaction) {
        if (transaction != null) {
            System.out.println("Date: " + transaction.getDate());
            System.out.println("Amount: " + transaction.getAmount());
            System.out.println("Description: " + transaction.getDescription());
        } else {
            System.out.println("No transaction found.");
        }
    }
    private static void printHistogram(Map<Month, Map<String, Double>> histogram) {
        for (Month month : histogram.keySet()) {
            System.out.println("Month: " + month);
            Map<String, Double> expenses = histogram.get(month);
            for (String category : expenses.keySet()) {
                System.out.println("  Category: " + category + ", Amount: " + expenses.get(category));
            }
        }
    }
}



