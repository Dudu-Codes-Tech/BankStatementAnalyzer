import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankStatementProcessor {
    private final List<BankTransaction> bankTransactions;
    public static double calculateTotalAmount(final List<BankTransaction> bankTransactions) {
        double total = 0d;
        for (final BankTransaction bankTransaction : bankTransactions) {
            total += bankTransaction.getAmount();

        }
        return total;
    }

    public static List<BankTransaction> selectInMonth(final List<BankTransaction> bankTransactions, final Month month) {
        final List<BankTransaction> bankTransactionsInMonth = new ArrayList<>();
        for (final BankTransaction bankTransaction : bankTransactions) {

            if (bankTransaction.getDate().getMonth() == month) {
                bankTransactionsInMonth.add(bankTransaction);

            }
        }
        return bankTransactionsInMonth;
    }

    public BankStatementProcessor(List<BankTransaction> bankTransactions) {
        this.bankTransactions = bankTransactions;
    }

    public double calculateTotalAmount(){
        double total =0;
        for(final BankTransaction bankTransaction : bankTransactions){
            total += bankTransaction.getAmount();
        }
        return total;
    }
    public double calculateTotalInMonth(final Month month){
        double total =0;
        for(final BankTransaction bankTransaction: bankTransactions){
            if(bankTransaction.getDate().getMonth() == month){
                total += bankTransaction.getAmount();
            }
        }
        return  total;
    }
    public double calculateTotalForCategory(final String category){
       double total =0;
       for(final BankTransaction bankTransaction : bankTransactions){
           if(bankTransaction.getDescription().equals(category)){
               total += bankTransaction.getAmount();
           }
       }
       return  total;
    }
    public BankTransaction findMaximumTransactionInDateRange(LocalDate startDate, LocalDate endDate) {
        BankTransaction maxTransaction = null;

        for (final BankTransaction bankTransaction : bankTransactions) {
            if (!bankTransaction.getDate().isBefore(startDate) && !bankTransaction.getDate().isAfter(endDate)) {
                if (maxTransaction == null || bankTransaction.getAmount() > maxTransaction.getAmount()) {
                    maxTransaction = bankTransaction;

                }

            }
        }
        return maxTransaction;
    }

    public BankTransaction findMinimumTransactionInDateRange(LocalDate startDate, LocalDate endDate){
        BankTransaction minTransaction = null;
        for(final BankTransaction bankTransaction : bankTransactions){
            if(!bankTransaction.getDate().isBefore(startDate) && !bankTransaction.getDate().isAfter(endDate)){
                if(minTransaction == null || bankTransaction.getAmount() < minTransaction.getAmount()){
                    minTransaction = bankTransaction;
                }
            }
        }
        return minTransaction;
    }
    public Map<Month, Map<String, Double>> getExpenseHistogram() {
        Map<Month, Map<String, Double>> histogram = new HashMap<>();
        for (final BankTransaction bankTransaction : bankTransactions) {
            Month month = bankTransaction.getDate().getMonth();
            String description = bankTransaction.getDescription();
            double amount = bankTransaction.getAmount();

            histogram.putIfAbsent(month, new HashMap<>());
            Map<String, Double> categoryMap = histogram.get(month);
            categoryMap.put(description, categoryMap.getOrDefault(description, 0.0) + amount);
        }
        return histogram;
    }
}
