import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Optional;

public class BankStatementCSVParserTest{

    private final BankStatementParser statementParser = new BankStatementCSVParser();

    @Test
    public void shouldParseOneCorrectLine() throws Exception {
        final String line = "30-01-2017,-50,Mc Donald's";

        final BankTransaction result = statementParser.parseFrom(line);

        final BankTransaction expected
                = new BankTransaction(LocalDate.of(2017, Month.JANUARY, 30), (double) -50, "Tesco");
        final double tolerance = 0.0d;

        Assert.assertEquals(expected.getDate(), result.getDate());
        Assert.assertEquals(expected.getAmount(), result.getAmount(), tolerance);
        Assert.assertEquals(expected.getDescription(), result.getDescription());
    }
    @Test
    public void shouldParseOneCorrectLine1() throws Exception {
        final String line = "12-01-2024 ,70,Groceries ";

        final BankTransaction result = statementParser.parseFrom(line);

        final BankTransaction expected
                = new BankTransaction(LocalDate.of(2024, Month.JANUARY, 12), (double) -50, "Groceries");
        final double tolerance = 0.0d;

        Assert.assertEquals(expected.getDate(), result.getDate());
        Assert.assertEquals(expected.getAmount(), result.getAmount(), tolerance);
        Assert.assertEquals(expected.getDescription(), result.getDescription());
    }
    @Test
    public void shouldMaxTransactionInRange() throws Exception {
        final List<String> lines = List.of("30-01-2017,-100,Deliveroo," +
                "15-01-2024,-50,Food",
                "01-20-2024,6000,Salary" ,
                "01-02-2024,2000,Royalties",
                "02-02-2024,-4000,Rent"

                ) ;

        final List<BankTransaction> transactions = statementParser.parseLinesFrom(lines);
        final BankStatementProcessor processor   = new BankStatementProcessor(transactions);

        final LocalDate startDate = LocalDate.of(2024,1,15);
        final LocalDate endDate   = LocalDate.of(2024,2,2);

       final Optional<BankTransaction> maxTransaction = Optional.ofNullable(processor.findMaximumTransactionInDateRange(startDate, endDate));

       Assert.assertTrue(maxTransaction.isPresent());;
       Assert.assertEquals(6000, maxTransaction.get().getAmount(), 0.0d);

    }


}
